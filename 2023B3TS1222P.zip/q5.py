# from collections import deque
# stack=deque

from collections import deque

class stack:
    def __init__(self):
        self.container = deque()

    def push(self,val):
        self.container.append(val)

    def pop(self):
        return self.container.pop()
    
    def print(self):
        for ele in self.container:
            print(ele, end=' ')
        print()

    def is_empty(self):
        return len(self.container)==0
    
s=stack()
while(True):
    print("1. Push <Data> \n2. Pop \n3. Print \n4. Exit")
    input_line=input()
    input_values=input_line.split()
    if(len(input_values)==1):
        choice=input_values[0]
    elif(len(input_values))>1:
        choice=input_values[0]
        val=input_values[1]
    else:
        print("Give a valid input.")
    
    if(choice=="Push" or choice=="push"):
        s.push(val)
    elif(choice=="Pop" or choice=="pop"):
        if(s.is_empty()):
            print("underflow")
        else:
            print(s.pop())
    elif(choice=="Print" or choice=="print"):
        s.print()
    elif(choice=="Exit" or choice=="exit"):
        break
    else:
        print("Give a valid input.")