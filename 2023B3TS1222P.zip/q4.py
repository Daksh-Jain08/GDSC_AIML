t=int(input())
while(t!=0):
    str=input()
    c=0
    i,j=0,-1
    for i in range(int(len(str)/2)):
        if({str[i],str[j]}=={'0','1'} or {str[i],str[j]}=={'1','0'}):
            c+=1
            j-=1
        else:
            break
    ans=len(str)-(c*2)
    print(ans)
    t-=1