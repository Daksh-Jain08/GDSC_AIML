t=int(input("Enter the number of test cases: "))
while(t!=0):
    a,b=input().split()
    c=0
    for j in b:
        for i in range(0,len(a)):
            if j==a[i]:
                c+=1
                break
    if c==len(a):
        print("YES")
    else:
        print("NO")
    t-=1