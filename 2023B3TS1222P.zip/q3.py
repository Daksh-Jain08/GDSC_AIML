n=int(input())
array_1=[[0]*n]*n
for i in range(0,n):
    array_1[i]=list(map(int, input().split()))

array_2=[[0]*n]*n
for i in range(0,n):
    array_2[i]=list(map(int, input().split()))

tr=0
for i in range(n):
    k=0
    for j in range(n):
        k+=array_1[i][j]*array_2[j][i]
    tr+=k
print(tr)